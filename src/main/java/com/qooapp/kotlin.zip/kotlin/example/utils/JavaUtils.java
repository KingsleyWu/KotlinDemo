package com.qooapp.kotlin.example.utils;

import java.util.Random;

public class JavaUtils {

    public static int test(){
        return new Random(3).nextInt();
    }
}
