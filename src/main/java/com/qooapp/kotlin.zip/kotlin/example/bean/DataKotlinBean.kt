package com.qooapp.kotlin.example.bean

data class DataKotlinBean(var arg: Int = 0, var arg2: Int? = null, var arg3: String? = null)
