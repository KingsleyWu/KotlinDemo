package com.qooapp.kotlin.example

//fun main(args: Array<String>) {
//    println("Hello World")
//}

fun main() {
    println("Hello World")
}
